import { describe, it, expect } from 'vitest';

describe('App', () => {
  it('passes a simple test', () => {
    expect(true).toBe(true);
  });
});