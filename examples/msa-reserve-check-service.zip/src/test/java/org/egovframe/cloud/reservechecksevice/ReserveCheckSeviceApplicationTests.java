package org.egovframe.cloud.reservechecksevice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles(profiles = "test")
class ReserveCheckSeviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
